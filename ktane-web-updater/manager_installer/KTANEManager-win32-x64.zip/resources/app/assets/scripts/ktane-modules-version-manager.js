function fillModuleVersionData(moduleData, cb) {
    getLatestVersion(moduleData.id, latestVersion => {
        moduleData.latestVersion = latestVersion;
        moduleData.canUpdate = isGreater(moduleData.latestVersion, moduleData.currentVersion);
        cb();
    });
}

function getLatestVersion(moduleId, cb) {
    let versionFilePath = "https://vadympetruk.github.io/ktane-web-updater/update_files/" + moduleId + "/latest_version.txt";

    let xhr = new XMLHttpRequest();
    xhr.open('GET', versionFilePath);
    xhr.send();

    xhr.onload = function () {
        if (xhr.status !== 200) {
            cb(stringToVersion("0.0.0"));
        } else { // show the result
            cb(stringToVersion(xhr.responseText));
        }
    };
}

function getUpdateFileUrl(moduleId, version) {
    return "https://vadympetruk.github.io/ktane-web-updater/update_files/"
        + moduleId + "/" + moduleId + "_" + versionToString(version) + ".bin";
}

function updateModule(moduleData) {
    console.log("update module " + moduleData.id + " to version " + versionToString(moduleData.latestVersion));

    let updateFileUrl = getUpdateFileUrl(moduleData.id, moduleData.latestVersion);
    let wifiSsid = document.getElementById("wifissid").value;
    let wifiPassword = document.getElementById("wifipswd").value;
    sendUpdateMessage(moduleData.id, updateFileUrl, wifiSsid, wifiPassword);
}

function versionToString(version) {
    return version.join('.');
}

function stringToVersion(strVersion) {
    return strVersion.trim().split('.');
}

function isGreater(version1, version2) {
    for (let i = 0; i < version1.length; i++) {
        if (version1[i] > version2[i]) return true;
    }

    return false;
}

function getUpdateFileURL(moduleId, version) {
    let filePath = './update_files/' + moduleId + '/' + moduleId + '_' + version + '.bin';

    console.log(filePath);

    const xmlHttp = new XMLHttpRequest();
    xmlHttp.open("GET", filePath, false);
    xmlHttp.send();
    return (xmlHttp.status === 200) ? xmlHttp.responseURL : null;
}