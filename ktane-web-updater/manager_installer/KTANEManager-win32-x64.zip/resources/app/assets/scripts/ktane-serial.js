const SerialPort = require('serialport');
const Readline = require('@serialport/parser-readline');
const Settings = require('electron-settings');

const messageType = {
    'ping': {intType: 1, handler: null},
    'pong': {intType: 2, handler: handlePong},

    'getModules': {intType: 3, handler: null},
    'onGetModules': {intType: 4, handler: handleGetModules},

    'update': {intType: 5, handler: null},
    'updated': {intType: 6, handler: handleUpdated},
};

let ActivePort;

function setupSerialPorts() {
    SerialPort.list(function (err, ports) {
        ports.forEach(function (port) {
            setupPortListener(port.comName);
        });

        function setupPortListener(comName) {
            console.log("found serial port: " + comName);
            const port = new SerialPort(comName, {
                baudRate: 115200
            });

            const parser = port.pipe(new Readline({delimiter: '\n'}));
            parser.on('data', (msg) => {
                handleData(port, msg);
            });

            port.on('error', function (err) {
                console.log('Error: ', err.message)
            });

            sendPingMessage(port);
        }

        function handleData(port, message) {
            console.log('Received message: ', message);

            try {
                let jsonMessage = JSON.parse(message);
                let messageHandler = findMessageHandler(jsonMessage.type);
                if (messageHandler) {
                    messageHandler(port, jsonMessage.data);
                } else {
                    console.warn("can't handle message: " + message);
                }
            } catch (err) {
                console.warn(err.message); //just ignore incorrect messages
            }
        }

        function findMessageHandler(intType) {
            for (let key in messageType) {
                if (!messageType.hasOwnProperty(key)) continue;

                if (messageType[key].intType === intType) {
                    return messageType[key].handler;
                }
            }
            return null;
        }
    });
}

function setupWifiPreferences() {
    if (Settings.has('wifi.ssid')) {
        document.getElementById("wifissid").value = Settings.get('wifi.ssid');
        document.getElementById("wifipswd").value = Settings.get('wifi.pswd');
    }
}

//==================== HELPER FUNCTIONS =======================
function createRequestMessage(msgType, data) {
    return JSON.stringify({type: msgType.intType, data: data})
}

function sendMessage(port, message) {
    port.write(message, function (err) {
        if (err) {
            return console.log('Error on write: ', err.message);
        }
        console.log('message written: ' + message);
    });
}

//==================== REQUEST MESSAGES =======================
function sendPingMessage(port) {
    sendMessage(port, createRequestMessage(messageType.ping));
}

function sendGetModulesMessage() {
    if (ActivePort === null) {
        console.error("ActivePort not found yet");
        return;
    }
    sendMessage(ActivePort, createRequestMessage(messageType.getModules));
}

function sendUpdateMessage(moduleId, updateFileUrl, wifiSsid, wifiPassword) {
    Settings.set('wifi', {
        ssid: wifiSsid,
        pswd: wifiPassword
    });

    if (ActivePort === null) {
        console.error("ActivePort not found yet");
        return;
    }

    const data = {
        moduleId: moduleId,
        wifiSsid: wifiSsid,
        wifiPassword: wifiPassword,
        updateFileUrl: updateFileUrl,
        fingerprint: [0x70, 0x0B, 0x6F, 0x62, 0x4F, 0x41, 0xEB, 0x1A, 0x42, 0x3F, 0x73, 0x5A, 0xDA, 0x96, 0x98, 0x2D, 0x7F, 0x2B, 0x75, 0x6F]
        // fingerprint: [0xCA, 0x06, 0xF5, 0x6B, 0x25, 0x8B, 0x7A, 0x0D, 0x4F, 0x2B, 0x05, 0x47, 0x09, 0x39, 0x47, 0x86, 0x51, 0x15, 0x19, 0x84]
};

    sendMessage(ActivePort, createRequestMessage(messageType.update, data));
}

//========================= HANDLERS ==========================

function handlePong(port, data) {
    ActivePort = port;
    sendGetModulesMessage();
}

function handleGetModules(port, data) {
    updateActiveModules(data);
}

function handleUpdated(port, data) {
    console.log("module updated")
}

