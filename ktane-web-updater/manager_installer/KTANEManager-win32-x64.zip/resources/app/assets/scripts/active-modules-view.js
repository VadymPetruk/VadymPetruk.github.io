function cleanupActiveModulesView() {
    let activeModulesTable = getActiveModulesTable();
    let tableRows = activeModulesTable.getElementsByTagName('tr');
    let rowCount = tableRows.length;

    for (let x = rowCount - 1; x > 0; x--) {
        activeModulesTable.removeChild(tableRows[x]);
    }
}

function getActiveModulesTable() {
    return document.getElementById('modulesTable');
}

function showNewModule(moduleData) {
    let row = document.createElement('tr');

    let moduleNameCell = document.createElement('td');
    appendTextNode(moduleNameCell, moduleData.id);
    row.appendChild(moduleNameCell);

    let currentVersionCell = document.createElement('td');
    appendTextNode(currentVersionCell, versionToString(moduleData.currentVersion));
    row.appendChild(currentVersionCell);

    let latestVersionCell = document.createElement('td');
    appendTextNode(latestVersionCell, versionToString(moduleData.latestVersion));
    row.appendChild(latestVersionCell);

    let updateCell = document.createElement('td');
    if (moduleData.canUpdate) {
        appendButton(updateCell, 'Update to ' + versionToString(moduleData.latestVersion), function (button) {
            button.innerHTML = "Updating...";
            button.disabled = true;
            updateModule(moduleData);
        });
    } else {
        appendTextNode(updateCell, '-');
    }
    row.appendChild(updateCell);

    getActiveModulesTable().appendChild(row);
}


function appendTextNode(parent, text) {
    let textNode = document.createTextNode(text);
    parent.appendChild(textNode);
}

function appendButton(parent, btnText, onClick) {
    let button = document.createElement("button");
    button.innerHTML = btnText;

    button.addEventListener("click", function () {
        onClick(button);
    });

    parent.appendChild(button);

    return button;
}