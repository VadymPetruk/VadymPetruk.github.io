function updateActiveModules(activeModules) {
    cleanupActiveModulesView();
    for (let i = 0; i < activeModules.length; i++) {
        let moduleData = createViewModuleData(activeModules[i]);
        fillModuleVersionData(moduleData, () => {
            showNewModule(moduleData);
        });
    }

    function createViewModuleData(moduleData) {
        return {
            id: moduleData.moduleId,
            currentVersion: stringToVersion(moduleData.moduleVersion),
            latestVersion: null,
            canUpdate: null
        };
    }
}

function refreshModules() {
    cleanupActiveModulesView();
    sendGetModulesMessage();
}


