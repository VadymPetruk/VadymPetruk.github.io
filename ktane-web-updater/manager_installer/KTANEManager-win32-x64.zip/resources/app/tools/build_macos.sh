#!/bin/bash

# npm install electron --save-dev
# npm install -g electron-packager --save-dev
electron-packager .. KTANEManager --platform=darwin --arch=all --out=../builds/ --overwrite
