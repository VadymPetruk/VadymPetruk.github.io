#!/bin/bash

# npm i electron-installer-dmg -g
electron-installer-dmg ../builds/KTANEManager-darwin-x64/KTANEManager.app/ KTANEManager --out=../builds/ --overwrite 
