#!/bin/bash

rm -rf ../builds/*
